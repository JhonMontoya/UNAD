'''
    Desarrollado por: Jhonathan D. Guerrero Montoya
    Fecha: 29 - sep - 2025
    Descripción:
        Grupo de ejercicios #2 - Punto 3
        Enunciado:
            Crear una clase abstracta Forma con el método abstracto calcular_area. Crear clases Circulo y Cuadrado que hereden de Forma y calculen el área de acuerdo a la forma. 
    
'''
#Creamos la clase abstracta Forma
from abc import ABC, abstractmethod

class Forma(ABC):
    @abstractmethod
    def calcular_area(self):
        pass

#Creamos las clases Circulo y Cuadrado que heredan de Forma
class Circulo(Forma):
    def __init__(self, radio):
        self.radio = radio

    def calcular_area(self):
        return 3.14 * self.radio**2

class Cuadrado(Forma):
    def __init__(self, lado):
        self.lado = lado

    def calcular_area(self):
        return self.lado**2
    
#Ejemplo de uso
if __name__ == "__main__":
    circulo = Circulo(5)
    area_circulo = circulo.calcular_area()
    print(f"El área del círculo es: {area_circulo}")

    cuadrado = Cuadrado(4)
    area_cuadrado = cuadrado.calcular_area()
    print(f"El área del cuadrado es: {area_cuadrado}")