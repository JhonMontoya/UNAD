'''
    Desarrollado por: Jhonathan D. Guerrero Montoya
    Fecha: 29 - sep - 2025
    Descripción:
        Grupo de ejercicios #2 - Punto 2
        Enunciado:
            Crear una clase Estudiante con atributos nombre, notas (lista). Añadir un método que calcule el promedio de las notas.
    
'''
#Creamos la clase estudiante
class Estudiante:
    def __init__(self, nombre, notas):
        #definimos los atributos de nombre y notas
        self.nombre = nombre
        self.notas = notas

    #Creamos un método para calcular el promedio de las notas
    def calcular_promedio(self):
        if len(self.notas) == 0:
            return 0
        return sum(self.notas) / len(self.notas)
    
#Ejemplo de uso
if __name__ == "__main__":
    estudiante1 = Estudiante("Ana", [85, 90, 78, 92])
    promedio1 = estudiante1.calcular_promedio()
    print(f"El promedio de {estudiante1.nombre} es: {promedio1}")

    estudiante2 = Estudiante("Luis", [70, 75, 80])
    promedio2 = estudiante2.calcular_promedio()
    print(f"El promedio de {estudiante2.nombre} es: {promedio2}")