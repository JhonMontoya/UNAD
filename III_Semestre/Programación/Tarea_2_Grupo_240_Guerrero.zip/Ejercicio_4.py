'''
    Desarrollado por: Jhonathan D. Guerrero Montoya
    Fecha: 29 - sep - 2025
    Descripción:
        Grupo de ejercicios #2 - Punto 4
        Enunciado:
            Diseña una clase Libro con los atributos titulo, autor y numero_paginas. Agrega un método descripcion que devuelva una cadena con el título, el autor y el número de páginas del libro. Crea varios objetos de tipo Libro y muestra la descripción de cada uno.
'''
#Creamos la clase Libro
class Libro:
    def __init__(self, titulo, autor, numero_paginas):
        self.titulo = titulo
        self.autor = autor
        self.numero_paginas = numero_paginas

    def descripcion(self):
        return f"Título: {self.titulo}, Autor: {self.autor}, Páginas: {self.numero_paginas}"

#Ejemplo de uso
if __name__ == "__main__":
    libro1 = Libro("1984", "George Orwell", 328)
    libro2 = Libro("El Principito", "Antoine de Saint-Exupéry", 96)

    print(libro1.descripcion())
    print(libro2.descripcion())
