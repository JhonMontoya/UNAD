'''
    Desarrollado por: Jhonathan D. Guerrero Montoya
    Fecha: 29 - sep - 2025
    Descripción:
        Grupo de ejercicios #2 - Punto 5
        Enunciado:
            Diseña una clase Agenda que permita gestionar contactos. Cada contacto debe ser representado por un diccionario con nombre, telefono, y email. Agrega métodos agregar_contacto(contacto), eliminar_contacto(nombre), y buscar_contacto(nombre) para encontrar contactos. Crea una instancia de Agenda, agrega, elimina y busca contactos para probar su funcionamiento. 
'''
#Creamos la clase Agenda
class Agenda:
    def __init__(self):
        self.contactos = []
    #Creamos los métodos
    def agregar_contacto(self, contacto):
        self.contactos.append(contacto)

    def eliminar_contacto(self, nombre):
        self.contactos = [c for c in self.contactos if c["nombre"] != nombre]

    def buscar_contacto(self, nombre):
        for contacto in self.contactos:
            if contacto["nombre"] == nombre:
                return contacto
        return None

#Ejemplo de uso
if __name__ == "__main__":
    agenda = Agenda()
    agenda.agregar_contacto({"nombre": "Juan", "telefono": "123456789", "email": "juan@example.com"})
    agenda.agregar_contacto({"nombre": "Maria", "telefono": "987654321", "email": "maria@example.com"})

    print("Buscar contacto 'Juan':")
    print(agenda.buscar_contacto("Juan"))

    print("Eliminar contacto 'Maria'")
    agenda.eliminar_contacto("Maria")

    print("Buscar contacto 'Maria':")
    print(agenda.buscar_contacto("Maria"))