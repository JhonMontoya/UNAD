'''
    Desarrollado por: Jhonathan D. Guerrero Montoya
    Fecha: 29 - sep - 2025
    Descripción:
        Grupo de ejercicios #2 - Punto 5
        Enunciado:
            Encapsulamiento y métodos estáticos: Crear una clase Vehiculo con un método estático identificar_tipo que retorne Terrestre, Acuático, o Aéreo según un tipo pasado como parámetro.  
'''
#Creamos la clase Vehiculo
class Vehiculo:
    @staticmethod
    def identificar_tipo(tipo):
        if tipo == "terrestre":
            return "Terrestre"
        elif tipo == "acuático":
            return "Acuático"
        elif tipo == "aéreo":
            return "Aéreo"
        else:
            return "Desconocido"

#Ejemplo de uso
if __name__ == "__main__":
    tipo_vehiculo1 = Vehiculo.identificar_tipo("terrestre")
    print(f"El vehículo es de tipo: {tipo_vehiculo1}")

    tipo_vehiculo2 = Vehiculo.identificar_tipo("acuático")
    print(f"El vehículo es de tipo: {tipo_vehiculo2}")

    tipo_vehiculo3 = Vehiculo.identificar_tipo("aéreo")
    print(f"El vehículo es de tipo: {tipo_vehiculo3}")

    tipo_vehiculo4 = Vehiculo.identificar_tipo("espacial")
    print(f"El vehículo es de tipo: {tipo_vehiculo4}")