'''
    Desarrollado por: Jhonathan D. Guerrero Montoya
    Fecha: 29 - sep - 2025
    Descripción:
        Grupo de ejercicios #2 - Punto 1
        Enunciado:
            Crear un objeto de la clase Persona y asignar valores a sus atributos nombre y edad.
    
'''

#Creamos la clase persona
class persona:
    def __init__(self, nombre, edad):
        #definimos los atributos de nombre y edad
        self.nombre = nombre
        self.edad = edad

    #Adicionalmente creamos un método para saludar
    def saludar(self):
        print(f"Hola, mi nombre es {self.nombre} y tengo {self.edad} años.")

#Prueba de la clase persona
persona1 = persona("Juan", 30)
persona1.saludar()