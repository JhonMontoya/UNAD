class Empleado:
    def __init__(self, nombre, salario):
        self._nombre = nombre
        self._salario = salario

    def get_nombre(self):
        return  self._nombre

    def get_salario(self):
        return self._salario
    
    def set_nombre(self, nuevo_nombre):
        self._nombre = nuevo_nombre
        print("Nombre actualizado exitosamente.")
        return True
    
    def set_salario(self, nuevo_salario):
        if nuevo_salario >= 0:
            self._salario = nuevo_salario
            print("Salario actualizado exitosamente.")
            return True
        else:
            print("El salario no puede ser negativo.")
            return False

#Ejemplo de uso
mi_empleado = Empleado("Juan Perez", 3000)
print("Nombre del empleado:", mi_empleado.get_nombre())
print("Salario del empleado:", mi_empleado.get_salario())