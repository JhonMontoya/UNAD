class Juego:
    def __init__(self): 
        self.__puntuacion = 0

    def agregar_puntos(self, puntos):
        if puntos > 0:
            self.__puntuacion += puntos
        else:
            print("Error: Los puntos deben ser positivos.")

    def restar_puntos(self, puntos):
        if 0 < puntos <= self.__puntuacion:
            self.__puntuacion -= puntos
        else:
            print("Error: No se pueden restar más puntos de los que se tienen.")

    def get_puntuacion(self):
        return self.__puntuacion

#Ejemplo de uso
mi_juego = Juego()
mi_juego.agregar_puntos(10)
mi_juego.restar_puntos(5)
print("Puntuación actual:", mi_juego.get_puntuacion())