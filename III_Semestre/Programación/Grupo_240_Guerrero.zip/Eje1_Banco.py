class Banco:
    def __init__(self, balance=0):
        self._balance = balance
    def depositar(self, cantidad):
        if cantidad > 0:
            self._balance += cantidad
            print("Depósito exitoso.")
            return True
        else:
            print("Cantidad inválida para depositar.")
            return False

    def retirar(self, cantidad):
        if 0 < cantidad <= self._balance:
            self._balance -= cantidad
            print("Retiro exitoso.")
            return True
        else:
            print("Cantidad inválida para retirar.")
            return False

    def obtener_balance(self):
        return self._balance

# Ejemplo de uso
mi_banco = Banco(1000)
mi_banco.depositar(500)
mi_banco.retirar(200)
print("Saldo actual:", mi_banco.obtener_balance())