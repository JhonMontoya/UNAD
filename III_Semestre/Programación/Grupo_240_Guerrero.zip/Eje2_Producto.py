class Producto:
    def __init__(self, precio,):
        self._precio = precio
       
    def set_precio(self, nuevo_precio):
        if nuevo_precio >= 0:
            self._precio = nuevo_precio
            print("Precio actualizado exitosamente.")
            return True
        else:
            print("El precio no puede ser negativo.")
            return False
    
    def get_precio(self):
        return self._precio
    
    def aplicar_descuento(self, porcentaje):
        if 0 < porcentaje < 100:
            descuento = self._precio * (porcentaje / 100)
            self._precio -= descuento
            print(f"Descuento del {porcentaje}% aplicado exitosamente.")
            return True
        else:
            print("Porcentaje de descuento inválido.")
            return False
        
#Ejemplo de uso
mi_producto = Producto(100)
mi_producto.aplicar_descuento(15)
print("Precio con descuento:", mi_producto.get_precio())
mi_producto = Producto(100)