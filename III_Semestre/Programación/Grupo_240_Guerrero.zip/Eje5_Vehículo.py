class Vehiculo:
    def __init__(self, marca, velocidad_maxima):
        self.__marca = marca
        # Se asegura que la velocidad máxima no supere los 200 km/h
        self.__velocidad_maxima = velocidad_maxima if velocidad_maxima <= 200 else 200

    def get_marca(self):
        return self.__marca
    
    def get_velocidad_maxima(self):
        return self.__velocidad_maxima
    
    def set_velocidad_maxima(self, nueva_velocidad):
        if 0 < nueva_velocidad <= 200:
            self.__velocidad_maxima = nueva_velocidad
        else:
            print("Error: La velocidad máxima debe estar entre 1 y 200 km/h.")

#Ejemplo de uso
mi_vehiculo = Vehiculo("Toyota", 220)
print("Marca del vehículo:", mi_vehiculo.get_marca())
print("Velocidad máxima del vehículo:", mi_vehiculo.get_velocidad_maxima())
mi_vehiculo.set_velocidad_maxima(250)