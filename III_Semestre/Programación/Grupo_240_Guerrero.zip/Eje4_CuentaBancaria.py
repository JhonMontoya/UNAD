class CuentaBancaria:
    def __init__(self, saldo_inicial=0):
        self.__saldo = saldo_inicial

    def depositar(self, monto):
        if monto > 0:
            self.__saldo += monto
        else:
            print("Error: Monto de depósito inválido.")

    def retirar(self, monto):
        if 0 < monto <= self.__saldo:
            self.__saldo -= monto
        else:
            print("Error: Fondos insuficientes o monto inválido.")

    def consultar_saldo(self):
        return self.__saldo
    
#Prueba de la clase CuentaBancaria
mi_cuenta = CuentaBancaria(1000)
mi_cuenta.depositar(500)
mi_cuenta.retirar(200)
print("Saldo actual:", mi_cuenta.consultar_saldo())